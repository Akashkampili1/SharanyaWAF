---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: timokoessler

---

- Is your feature request related to a problem?
- Describe the solution you'd like.
- Describe alternatives you've considered.
- Add any other context about the feature request.
