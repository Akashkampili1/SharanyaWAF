module.exports = require('./lib/easy-waf');
