const express = require('express');
const sharanya = require('./lib/easy-waf');
const helmet = require('helmet');
const fs = require('fs');
const app = express();
const port = 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));



app.use(helmet());

app.use(
  sharanya({
    allowedHTTPMethods: ['GET', 'POST', 'HEAD', 'OPTIONS'],
    ipBlacklist: ['1.1.1.1', '2.2.2.2'],
    ipWhitelist: ['::1', '172.16.0.0/12'],
    queryUrlWhitelist: ['github.com'],
    customBlockedPage: `<!DOCTYPE html><html lang="en" style="height:95%;">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>403 Forbidden</title>
            <style>p { line-height: 20px; };</style>
        </head>
        <body style="font-family:sans-serif;height:100%;">
            <div style="display:flex;justify-content:center;align-items:center;height:100%;">
                <div style="max-width:90%;word-wrap:break-word;">
                    <h1 style="margin-bottom:10px;">🛑 Request blocked</h1>
                    <h3 style="font-weight:normal;margin-top:0px;margin-bottom:5px;margin-left:52px;">403 Forbidden</h3>
                    <hr style="margin-top:1rem;margin-bottom:1rem;border:0;border-top:1px solid rgba(0, 0, 0, 0.1);">
                    <p>This website uses a firewall called sharanya to protect itself from online attacks.<br>
                    You have sent a suspicious request, therefore your request has been blocked.<br>
                    <strong>This is a custom blocked page.</strong></p>
                    <hr style="margin-top:1rem;margin-bottom:1rem;border:0;border-top:1px solid rgba(0, 0, 0, 0.1);">
                    <p>Time: {dateTime}<br>
                    Your IP: {ip}<br>
                    Reference ID: {referenceID}</p>
                </div>
            </div>
        </body>
    </html>`,
    modules: {
      directoryTraversal: {
        enabled: true,
        excludePaths: /^\/exclude\//i,
      },
    },
  })
);
app.use(express.static('public'));

app.get('/', function (req, res) {
  res.status(200).send('app is working');
});

// POST route to receive input and store it in "logs.json"
app.post('/store', function (req, res) {
  try {
    const inputData = req.body;
    if (inputData) {
      // Read the existing logs from "logs.json"
      let existingLogs = [];
      if (fs.existsSync('logs.json')) {
        existingLogs = JSON.parse(fs.readFileSync('logs.json'));
      }

      // Append the new input data to the logs
      existingLogs.push(inputData);

      // Write the updated logs back to "logs.json"
      fs.writeFileSync('logs.json', JSON.stringify(existingLogs, null, 2));

      res.status(200).send('Data stored successfully.');
    } else {
      res.status(400).send('Invalid input data.');
    }
  } catch (error) {
    res.status(500).send('Error while storing data.');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
